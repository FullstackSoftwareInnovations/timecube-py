from .timecube import generate, timecubeLength
